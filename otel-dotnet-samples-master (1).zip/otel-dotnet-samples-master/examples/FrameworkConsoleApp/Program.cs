﻿using System;
using Microsoft.Extensions.Logging;
using OpenTelemetry.Logs;
using TpIcap.FrameworkConsoleApp.TelemetryGenerators;

namespace TpIcap.FrameworkConsoleApp;

internal class Program
{
    public static void Main(string[] args)
    {
        using var _ = new Telemetry();

        // Auto instrumentation in .Net Framework will not include hooking up logging.  This has to be done manually.

        var loggerFactory = LoggerFactory.Create(logging =>
        {
            logging.AddOpenTelemetry(otel =>
            {
                otel.IncludeFormattedMessage = true;
                otel.IncludeScopes = true;
                otel.AddOtlpExporter();
            });
        });
        var logger = loggerFactory.CreateLogger<Program>();
        logger.LogInformation("Starting application");


        using var generator = new TraceAndMetricGenerator(loggerFactory);
        generator.Start();

        Console.WriteLine("Trace and Metric generation started, data should show up in the OTEL collector shortly");
        Console.WriteLine("Press any key to exit...");
        Console.ReadKey();
    }
}