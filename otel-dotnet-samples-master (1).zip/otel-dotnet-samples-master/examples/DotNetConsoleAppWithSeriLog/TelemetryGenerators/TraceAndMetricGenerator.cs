using System.Globalization;
using Microsoft.Extensions.Logging;

namespace TpIcap.DotNetConsoleAppWithSeriLog.TelemetryGenerators;

internal class TraceAndMetricGenerator : IDisposable
{
    public const string RequestPath = "/api/request";
    private readonly SampleClient _client;
    private readonly SampleServer _server;
    private ILogger<TraceAndMetricGenerator> _logger;

    public TraceAndMetricGenerator(ILoggerFactory loggerFactory)
    {
        _logger = loggerFactory.CreateLogger<TraceAndMetricGenerator>();
        _client = new(loggerFactory.CreateLogger<SampleClient>());
        _server = new(loggerFactory.CreateLogger<SampleServer>());
    }

    public void Dispose()
    {
        _client.Dispose();
        _server.Dispose();
    }

    public void Start(ushort port = 19999)
    {
        _logger.LogInformation("Starting Trace and Metric generation");
        var url = $"http://localhost:{port.ToString(CultureInfo.InvariantCulture)}{RequestPath}/";
        _server.Start(url);
        _client.Start(url);
    }
}