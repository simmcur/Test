Task run-otel-collector {
    $repositoryRoot = Join-Path $PSScriptRoot ".." -Resolve
    $dockerCommand = @"
docker container run --rm --interactive --tty ``
--mount type=bind,source=$(Join-Path $repositoryRoot "src/otel-collector/configuration"),target=/configuration ``
--publish 4317:4317 ``
--publish 4318:4318 ``
oci.tpicapcloud.com/otel/opentelemetry-collector:latest ``
--config=/configuration/config.yaml
"@
    Invoke-BuildExec { Invoke-Expression $dockerCommand } -Echo
}

Task run-aspire-dashboard {
    # https://learn.microsoft.com/en-us/dotnet/aspire/fundamentals/dashboard/configuration
    $dockerCommand = @"
docker container run --rm --interactive --tty ``
--publish 4317:18889 ``
--publish 18888:18888 ``
--env Dashboard__Frontend__AuthMode=Unsecured  ``
oci.tpicapcloud.com/dotnet/aspire-dashboard:8.2
"@
    Invoke-BuildExec { Invoke-Expression $dockerCommand } -Echo
}