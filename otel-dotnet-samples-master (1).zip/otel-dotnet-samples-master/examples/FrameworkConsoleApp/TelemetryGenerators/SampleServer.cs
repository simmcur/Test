using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace FrameworkExample;

internal class SampleServer(ILogger<SampleServer> logger) : IDisposable
{
    private readonly HttpListener listener = new();

    public void Dispose()
    {
        ((IDisposable)listener).Dispose();
    }

    public void Start(string url)
    {
        listener.Prefixes.Add(url);
        listener.Start();

        Task.Run(async () =>
        {
            using var source = new ActivitySource("TpIcap.FrameworkConsoleApp.SampleServer");

            var random = new Random();

            while (listener.IsListening)
                try
                {
                    var context = listener.GetContext();

                    using var activity = source.StartActivity($"{context.Request.HttpMethod}:{context.Request.Url!.AbsolutePath}", ActivityKind.Server);

                    var headerKeys = context.Request.Headers.AllKeys;
                    foreach (var headerKey in headerKeys)
                    {
                        var headerValue = context.Request.Headers[headerKey];
                        activity?.SetTag($"http.header.{headerKey}", headerValue);
                    }

                    string requestContent;
                    logger.LogInformation("Waiting for request content");
                    using (var childSpan = source.StartActivity("ReadStream", ActivityKind.Consumer))
                    using (var reader = new StreamReader(context.Request.InputStream, context.Request.ContentEncoding))
                    {
                        requestContent = reader.ReadToEnd();
                        childSpan?.AddEvent(new ActivityEvent("StreamReader.ReadToEnd"));
                    }

                    activity.SetTag("request.content", requestContent);
                    activity.SetTag("request.length", requestContent.Length.ToString());

                    // Simulate a random delay in processing the request.
                    await Task.Delay(random.Next(100, 5_000));

                    var echo = Encoding.UTF8.GetBytes("echo: " + requestContent);
                    context.Response.ContentEncoding = Encoding.UTF8;
                    context.Response.ContentLength64 = echo.Length;
                    context.Response.OutputStream.Write(echo, 0, echo.Length);
                    context.Response.Close();
                }
                catch (Exception)
                {
                    // expected when closing the listener.
                }
        });
    }
}