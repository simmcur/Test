$repositoryRoot = Join-Path $PSScriptRoot "../../.." -Resolve
. ( Join-Path $repositoryRoot ".workflow/common.ps1" )

Task init {
    $script:ProjectRoot = Join-Path $PSScriptRoot ".." -Resolve
    $script:Project = Split-Path $script:ProjectRoot -Leaf
    $script:ProjectPath = Join-Path $script:ProjectRoot "$($script:Project).csproj" -Resolve
    $script:RuntimeIdentifier = $IsLinux ? "linux-x64" : "win-x64"
}

Task clean init, {
    Set-Location $script:ProjectRoot
    Invoke-BuildExec { dotnet clean "$(Join-Path $PSScriptRoot "../$($script:Project).csproj" -Resolve)" --configuration Debug --runtime $script:RuntimeIdentifier } -Echo
}

Task restore init, {
    Set-Location $script:ProjectRoot
    Invoke-BuildExec { dotnet restore "$(Join-Path $PSScriptRoot "../$($script:Project).csproj" -Resolve)" } -Echo
}

Task build restore, {
    Set-Location $script:ProjectRoot
    Invoke-BuildExec { dotnet build "$(Join-Path $PSScriptRoot "../$($script:Project).csproj" -Resolve)" --configuration Debug --runtime $script:RuntimeIdentifier } -Echo
}

Task run build, {
    Set-Location $script:ProjectRoot

    $exeFolder = Join-Path $script:ProjectRoot "bin/Debug/net8.0/$($script:RuntimeIdentifier)" -Resolve

    # Set environment variables for OpenTelemetry Auto-Instrumentation
    $env:CORECLR_ENABLE_PROFILING = "1"
    $env:CORECLR_PROFILER = "{918728DD-259F-4A6A-AC2B-B85E1B658318}"
    $env:CORECLR_PROFILER_PATH_32 = Join-Path $exeFolder "OpenTelemetry.AutoInstrumentation.Native.dll" -Resolve
    $env:CORECLR_PROFILER_PATH_64 = Join-Path $exeFolder "OpenTelemetry.AutoInstrumentation.Native.dll" -Resolve
    $env:DOTNET_STARTUP_HOOKS = Join-Path $exeFolder "OpenTelemetry.AutoInstrumentation.StartupHook.dll" -Resolve

    $env:OTEL_DOTNET_AUTO_NETFX_REDIRECT_ENABLED = "false"
    $env:OTEL_DOTNET_AUTO_HOME = $exeFolder
    $env:OTEL_DOTNET_AUTO_RULE_ENGINE_ENABLED = "false"

    # Set OpenTelemetry environment variables to export telemetry to the local OTEL collector
    $env:OTEL_EXPORTER_OTLP_ENDPOINT = "http://localhost:4317"
    $env:OTEL_EXPORTER_OTLP_PROTOCOL = "grpc"

    # Set OpenTelemetry configuration environment variables
    $env:OTEL_SERVICE_NAME = $script:Project
    $env:OTEL_RESOURCE_ATTRIBUTES = "service.namespace=TpIcap.Samples"
    $env:OTEL_DOTNET_AUTO_METRICS_ADDITIONAL_SOURCES = "TpIcap.$($script:Project)*"
    $env:OTEL_DOTNET_AUTO_TRACES_ADDITIONAL_SOURCES = "TpIcap.$($script:Project)*"

    try {
        Invoke-BuildExec { dotnet run "$(Join-Path $PSScriptRoot "../$($script:Project).csproj" -Resolve)" --configuration Debug --runtime $script:RuntimeIdentifier } -Echo
    }
    finally {
        # Remove CORECLR environment variables so they don't impact running dotnet within the same session
        $env:CORECLR_ENABLE_PROFILING = $null
        $env:CORECLR_PROFILER = $null
        $env:CORECLR_PROFILER_PATH_32 = $null
        $env:CORECLR_PROFILER_PATH_64 = $null
        $env:DOTNET_STARTUP_HOOKS = $null
    }
}