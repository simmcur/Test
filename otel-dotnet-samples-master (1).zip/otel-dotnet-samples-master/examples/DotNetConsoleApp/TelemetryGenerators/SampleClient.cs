using System.Diagnostics;
using System.Globalization;
using System.Text;
using Microsoft.Extensions.Logging;

namespace TpIcap.DotNetConsoleApp.TelemetryGenerators;

internal class SampleClient(ILogger<SampleClient> logger) : IDisposable
{
    private CancellationTokenSource _cts;
    private Task _requestTask;

    public void Dispose()
    {
        if (_cts != null)
        {
            _cts.Cancel();
            try
            {
                _requestTask!.Wait();
            }
            catch (AggregateException)
            {
            }

            _requestTask.Dispose();
            _cts.Dispose();
        }
    }

    public void Start(string url)
    {
        _cts = new CancellationTokenSource();
        var cancellationToken = _cts.Token;

        var requestCounter = Telemetry.Meter.CreateCounter<long>("client.request.count", "requests", "Number of requests sent by the client");
        var requestDurationHistogram = Telemetry.Meter.CreateHistogram<long>("client.request.duration", "ms", "The duration of the client requests");

        _requestTask = Task.Run(
            (Func<Task>)(async () =>
            {
                using var source = new ActivitySource("TpIcap.DotNetConsoleApp.SampleClient");
                using var client = new HttpClient();

                while (!cancellationToken.IsCancellationRequested)
                {
                    var content = new StringContent($"client message: {DateTime.Now}", Encoding.UTF8);

                    using (var activity = source.StartActivity("POST:" + TraceAndMetricGenerator.RequestPath, ActivityKind.Client))
                    {
                        logger.LogInformation("Sending request");
                        requestCounter.Add(1);

                        activity.AddEvent(new ActivityEvent("PostAsync:Started"));
                        var requestTimer = Stopwatch.StartNew();
                        using var response = await client.PostAsync(url, content, cancellationToken).ConfigureAwait(false);
                        requestDurationHistogram.Record(requestTimer.ElapsedMilliseconds);
                        activity.AddEvent(new ActivityEvent("PostAsync:Ended"));

                        activity.SetTag("http.status_code", (int)response.StatusCode);

                        var responseContent = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                        activity.SetTag("response.content", responseContent);
                        activity.SetTag("response.length",
                            responseContent.Length.ToString(CultureInfo.InvariantCulture));

                        foreach (var header in response.Headers)
                            if (header.Value is IEnumerable<object> enumerable)
                                activity.SetTag($"http.header.{header.Key}", string.Join(",", enumerable));
                            else
                                activity.SetTag($"http.header.{header.Key}", header.Value.ToString());
                    }

                    try
                    {
                        await Task.Delay(TimeSpan.FromSeconds(1), cancellationToken).ConfigureAwait(false);
                    }
                    catch (TaskCanceledException)
                    {
                        return;
                    }
                }
            }),
            cancellationToken);
    }
}