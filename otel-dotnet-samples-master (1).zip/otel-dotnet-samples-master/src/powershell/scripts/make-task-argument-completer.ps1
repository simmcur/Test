<#
.SYNOPSIS
Argument completer for Task parameter of make script
#>
[CmdletBinding()]
param (
    $scriptFolder,
    $commandName,
    $parameterName,
    $wordToComplete,
    $commandAst,
    $fakeBoundParameters
)

$invokeBuildScript = Join-Path $PSScriptRoot "../modules/InvokeBuild/Invoke-Build.ps1" -Resolve
$buildScriptPath = Join-Path $scriptFolder ".workflow/main.ps1"

$buildScriptTasks = & $invokeBuildScript -File $buildScriptPath -Task ??
$taskNames = $buildScriptTasks.Keys

if ([string]::IsNullOrWhiteSpace($wordToComplete))
{
    return $taskNames
}

$taskNames | Where-Object { $_ -like "*$($wordToComplete)*" }