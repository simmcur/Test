# TP ICAP OpenTelemetry .Net Samples

[OpenTelemetry](https://opentelemetry.io/) (OTEL) is a key part of Observability within TP ICAP.  This repository contains samples for .Net which demonstrate how we use OpenTelemetry to instrument our applications to emit telemetry data.  These are largely inspired by the [OpenTeletry .Net examples](https://github.com/open-telemetry/opentelemetry-dotnet/tree/main/examples) which you are encouraged to explore in addition to this repository.

* [.Net Framework Console Application](examples/FrameworkConsoleApp)
* [.Net 8.0 Console Application](examples/DotNetConsoleApp)
* [.Net 8.0 with SeriLog Console Application](examples/DotNetConsoleAppWithSeriLog)

## Resources

* [OTEL .Net Documentation](https://opentelemetry.io/docs/languages/net/)
* [.Net OTEL SDK](https://github.com/open-telemetry/opentelemetry-dotnet)
* [Auto Instrumentation in .Net Documentation](https://opentelemetry.io/docs/zero-code/net/)
* [Auto Instrumentation in .Net GitHub](https://github.com/open-telemetry/opentelemetry-dotnet-instrumentation)
* [TP ICAP Semantic Conventions](https://scm.tpicapcloud.com/observability/slop/tpicap-semantic-conventions)