﻿// See https://aka.ms/new-console-template for more information

using Microsoft.Extensions.Logging;
using TpIcap.DotNetConsoleApp;
using TpIcap.DotNetConsoleApp.TelemetryGenerators;

// This empty configuration call is required to trigger Auto Instrumentation loading
var loggerFactory = LoggerFactory.Create(options => {});

var logger = loggerFactory.CreateLogger<Program>();
logger.LogInformation("Starting application");

using var _ = new Telemetry();

using var generator = new TraceAndMetricGenerator(loggerFactory);
generator.Start();

Console.WriteLine("Trace and Metric generation started, data should show up in the OTEL collector shortly");
Console.WriteLine("Press any key to exit...");
Console.ReadKey();