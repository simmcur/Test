# .Net Console Application

.Net 8.0 console application publishing logs, traces and metrics to an OTEL collector using the OpenTelemetry
Protocol (OTLP).

## Running the sample

To view telemetry data you need to run an OTEL collector. Two options are available running a local otel collector

```powershell
# From directory containing the sample
./make.ps1 run-otel-collector

# Container log output will show telemetry data
```

or running the .Net aspire dashbaord

```powershell
# From directory containing the sample
./make.ps1 run-aspire-dashboard

# Now open a browser to http://localhost:18888
```

Then in a different console window run the sample

```powershell
# From directory containing the sample
./make.ps1 run
```

## Implementation

The project uses
the [OpenTelemetry Auto Instrumentation](https://github.com/open-telemetry/opentelemetry-dotnet-instrumentation) project
and adds a reference to the OpenTelemetry.AutoInstrumentation nuget package. This provides assemblies which
automatically instrument certain aspects of the CLR and libraries. These libraries are loaded at runtime due to the
presence of environment variables which trigger the loading using the CLR profiler API. More
detail on this process can be found in
the [design documentation](https://github.com/open-telemetry/opentelemetry-dotnet-instrumentation/blob/main/docs/design.md).
Details of how to configure the instrumentation can be found in
the [configuration documentation](https://github.com/open-telemetry/opentelemetry-dotnet-instrumentation/blob/main/docs/config.md)

### Metrics

By default the following built-in metrics sources are enabled

* [Process](https://github.com/open-telemetry/opentelemetry-dotnet-contrib/tree/main/src/OpenTelemetry.Instrumentation.Process)
* [Runtieme](https://github.com/open-telemetry/opentelemetry-dotnet-contrib/tree/main/src/OpenTelemetry.Instrumentation.Runtime)
* [HTTP Client](https://github.com/open-telemetry/opentelemetry-dotnet-contrib/tree/main/src/OpenTelemetry.Instrumentation.Http)

In addition the application publishes custom metrics using the .Net Meter API

### Traces

The application publishes custom traces by hosting a simple HTTP server which a client continually sends requests to

### Logs

For auto instrumentation to work a call is required to LoggerFactory.Create, this call triggers an IL level hook to enable OTEL logging

```csharp
var loggerFactory = LoggerFactory.Create(logging => {});
```