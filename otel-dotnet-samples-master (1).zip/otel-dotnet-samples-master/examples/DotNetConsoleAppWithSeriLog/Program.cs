﻿using Microsoft.Extensions.Logging;
using Serilog;
using TpIcap.DotNetConsoleAppWithSeriLog;
using TpIcap.DotNetConsoleAppWithSeriLog.TelemetryGenerators;

Log.Logger = new LoggerConfiguration()
    .Enrich.FromLogContext()
    .Enrich.WithThreadId() // Doesn't follow OTEL semantic conventions on property name
    .WriteTo.Async(x => x.OpenTelemetry())
    .CreateLogger();

var loggerFactory = LoggerFactory.Create(options =>
{
    options.AddSerilog(Log.Logger);
});

var logger = loggerFactory.CreateLogger<Program>();
logger.LogInformation("Starting application");

using var _ = new Telemetry();

using var generator = new TraceAndMetricGenerator(loggerFactory);
generator.Start();

Console.WriteLine("Trace and Metric generation started, data should show up in the OTEL collector shortly");
Console.WriteLine("Press any key to exit...");
Console.ReadKey();