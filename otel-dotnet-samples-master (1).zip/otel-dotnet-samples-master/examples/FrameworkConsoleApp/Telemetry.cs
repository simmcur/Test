using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;

namespace TpIcap.FrameworkConsoleApp;

/// <summary>
/// Provides static API to obtain containers which emit telemetry
/// </summary>
public class Telemetry : IDisposable
{
    private readonly Meter _meter;

    public Telemetry()
    {
        if (Instance != null) return;
        // Details on the meter form the instrumentation scope
        // https://opentelemetry.io/docs/concepts/instrumentation-scope/
        _meter = new Meter("TpIcap.FrameworkConsoleApp", "1.0.0", new[]
        {
            // Tags on the meter translate into Instrumentation Scope attributes
            new KeyValuePair<string, object>("InstrumentationScopeAttributeA", "SampleValue")            
        });
        Instance = this;
    }

    private static Telemetry Instance { get; set; }
    public static Meter Meter => Instance._meter;

    public void Dispose()
    {
        Instance?._meter.Dispose();
        Instance = null;
    }
}