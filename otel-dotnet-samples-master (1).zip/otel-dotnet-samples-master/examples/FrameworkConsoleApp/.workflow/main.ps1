$repositoryRoot = Join-Path $PSScriptRoot "../../.." -Resolve
. ( Join-Path $repositoryRoot ".workflow/common.ps1" )

Task init {
    $script:ProjectRoot = Join-Path $PSScriptRoot ".." -Resolve
    $script:Project = Split-Path $script:ProjectRoot -Leaf
    $script:ProjectPath = Join-Path $script:ProjectRoot "$($script:Project).csproj" -Resolve
}

Task clean init, {
    Set-Location $script:ProjectRoot
    Invoke-BuildExec { dotnet clean "$(Join-Path $PSScriptRoot "../$($script:Project).csproj" -Resolve)" --configuration Debug --runtime win-x64 } -Echo
}

Task restore init, {
    Set-Location $script:ProjectRoot
    Invoke-BuildExec { dotnet restore "$(Join-Path $PSScriptRoot "../$($script:Project).csproj" -Resolve)" } -Echo
}

Task build restore, {
    Set-Location $script:ProjectRoot
    Invoke-BuildExec { dotnet build "$(Join-Path $PSScriptRoot "../$($script:Project).csproj" -Resolve)" --configuration Debug --runtime win-x64 } -Echo
}

Task run build, {
    Set-Location $script:ProjectRoot

    $exeFolder = Join-Path $script:ProjectRoot "bin/Debug/net4.8/win-x64" -Resolve

    # Set environment variables for OpenTelemetry Auto-Instrumentation
    $env:COR_ENABLE_PROFILING = "1"
    $env:COR_PROFILER = "{918728DD-259F-4A6A-AC2B-B85E1B658318}"
    $env:COR_PROFILER_PATH = Join-Path $exeFolder "OpenTelemetry.AutoInstrumentation.Native.dll" -Resolve
    $env:OTEL_DOTNET_AUTO_NETFX_REDIRECT_ENABLED = "false"
    $env:OTEL_DOTNET_AUTO_HOME = $exeFolder
    $env:OTEL_DOTNET_AUTO_RULE_ENGINE_ENABLED = "false"

    # Set OpenTelemetry environment variables to export telemetry to the local OTEL collector
    $env:OTEL_EXPORTER_OTLP_ENDPOINT = "http://localhost:4317"
    $env:OTEL_EXPORTER_OTLP_PROTOCOL = "grpc"

    # Set OpenTelemetry configuration environment variables
    $env:OTEL_SERVICE_NAME = $script:Project
    $env:OTEL_RESOURCE_ATTRIBUTES = "service.namespace=TpIcap.Samples"
    $env:OTEL_DOTNET_AUTO_METRICS_ADDITIONAL_SOURCES = "TpIcap.$($script:Project)*"
    $env:OTEL_DOTNET_AUTO_TRACES_ADDITIONAL_SOURCES = "TpIcap.$($script:Project)*"

    # $env:COR_ENABLE_PROFILING = $null
    # $env:COR_PROFILER = $null
    # $env:COR_PROFILER_PATH = $null

    Invoke-BuildExec { dotnet run "$(Join-Path $PSScriptRoot "../$($script:Project).csproj" -Resolve)" --configuration Debug --runtime win-x64 } -Echo
}