[CmdletBinding()]
param(
    [Parameter(Position = 1)]
    [ArgumentCompleter( { & ( Join-Path $PSScriptRoot "../../src/powershell/scripts/make-task-argument-completer.ps1" ) -Script $PSScriptRoot @args } )]
    [string]
    $Task = "."
)


$ErrorActionPreference = "Stop"

try
{
    $repositoryRoot = Join-Path $PSScriptRoot "../.." -Resolve
    & ( Join-Path $repositoryRoot "src/powershell/modules/InvokeBuild/Invoke-Build.ps1" ) -File ( Join-Path $PSScriptRoot ".workflow/main.ps1" ) -Task $Task
}
catch
{
    Get-Error
    throw
}